from config import *

def get_data_timer():
    current_datetime = datetime.datetime.now()
    formatted_datetime = current_datetime.strftime("%H:%M %d.%m.%Y")
    return formatted_datetime