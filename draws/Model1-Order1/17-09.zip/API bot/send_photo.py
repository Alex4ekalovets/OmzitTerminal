from config import *
from db import *


def send_photo(message: telebot.types.Message, text: str, file_name: str, keyboard: telebot.types.InlineKeyboardMarkup = None) -> None:
    with open(f'content/{file_name}.png', 'rb') as photo:
        bot.send_photo(message.chat.id, photo, caption=text, reply_markup=keyboard, parse_mode='html')