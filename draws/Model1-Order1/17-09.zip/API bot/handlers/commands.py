from config import *
from keyboards.inline import *
from steps.get_text import *
from steps.get_text_end import *
from steps.change_message import *
from steps.get_subscibe_info import *
from steps.get_auditoria import *
from steps.get_user_link import *
from send_photo import *
from db import *
from timers import *

def notif_1(message: telebot.types.Message):
    try:
        time.sleep(60 * 60)

        if db_get_reg_by_user_id(message.from_user.id) == 0:
            with open('content/video/26.mp4', 'rb') as videonote:
                bot.send_video_note(message.chat.id, videonote, reply_markup=keyboard_open_num9(), timeout = 60)
    except:
        pass
        
def notif_2(message: telebot.types.Message):
    try:
        time.sleep(60 * 7)

        if db_get_reg_by_user_id(message.from_user.id) == 0:
            url = db_select_link_referal(message.from_user.id)
            send_photo(message, f'{db_select_message(message.from_user.id, 21)}', '#21', keyboard_give(url))
    except:
        pass
        
def notif_3(message: telebot.types.Message):
    try:
        time.sleep(883 * 60)
        chat_member = bot.get_chat_member()
        url = db_select_link_referal(message.from_user.id)
        if chat_member:
            send_photo(message, f'{db_select_message(message.from_user.id, 22)}', '#22', keyboard_register(url))
    except:
        pass

def get_url_sub(start_param: str):
    '''Выдача url ссылки для кнопки'''
    if start_param == '1':
        return 'https://t.me/+6Tze2NpderpjNjZh'
    elif start_param == '2':
        return 'https://t.me/+ppakdFs0xxw0NDNh'
    elif start_param == '3':
        return 'https://t.me/+yixxdDJGN4tkYjYx'
    elif start_param == '4':
        return 'https://t.me/+yEUUlvhvwss1NTVh'
    elif start_param == '5':
        return 'https://t.me/+4aQWmbBqkDwwZmUx'
    else:
        return None

def handle_command_start(message: telebot.types.Message):
    restart = False
    time = get_data_timer()
    # Условие рестарта статистики
    print(db_select_user_exists(message.from_user.id))
    if db_select_user_exists(message.from_user.id) == True:
        start_param = message.text.split('/start ')[1] if len(message.text.split('/start ')) > 1 else None  # Если просто /start - понимаем что restart
        if start_param == None:
            start_param = db_select_auditoria(message.from_user.id)

            print('Вход в условия параметры при рестарте:', start_param)
            db_delete_user_by_user_id(message.chat.id)
            db_delete_qwotex_user(message.chat.id)
            restart = True
    
    if db_select_user_exists(message.from_user.id) == False: # Запись в базу
        if message.text.startswith('/start'):
            if restart == False:
                #start_param = message.text.split('/start ')[1] if len(message.text.split('/start ')) > 1 else None
                start_param = message.text.split('/start ')[1] if len(message.text.split('/start ')) > 1 else str('4')
            else:
                #start_param = str('4')
                start_param = str(start_param)
            print('Параметры при заходе в основные условия. Аудитория:', start_param)
            if start_param:
                if start_param == '1':  # При переходе по ссылке в бота с параметром start = 1
                    db_add_user_start(message.from_user.id, time, start_param, 'https://t.me/+6Tze2NpderpjNjZh', 'https://broker-qx.pro/sign-up/?lid=436185')
                elif start_param == '2': # При переходе по ссылке в бота с параметром start = 2
                    db_add_user_start(message.from_user.id, time, start_param, 'https://t.me/+ppakdFs0xxw0NDNh', 'https://broker-qx.pro/sign-up/?lid=436186')
                elif start_param == '3': # При переходе по ссылке в бота с параметром start = 3
                    db_add_user_start(message.from_user.id, time, start_param, 'https://t.me/+yixxdDJGN4tkYjYx', 'https://broker-qx.pro/sign-up/?lid=436187')
                elif start_param == '4': # При переходе по ссылке в бота с параметром start = 4
                    db_add_user_start(message.from_user.id, time, start_param, 'https://t.me/+yEUUlvhvwss1NTVh', 'https://broker-qx.pro/sign-up/?lid=438202')
                elif start_param == '5': # При переходе по ссылке в бота с параметром start = 5
                    db_add_user_start(message.from_user.id, time, start_param, 'https://t.me/+4aQWmbBqkDwwZmUx', 'https://broker-qx.pro/sign-up/?lid=438203')
                elif start_param == None:
                    bot.send_message(message.chat.id, 'You entered the bot via a direct link, but you need to go from the landing page. 5')
                    return
            else:
                bot.send_message(message.chat.id, 'You entered the bot via a direct link, but you need to go from the landing page. 4')
                return


        # Создаем объект потока, передавая функцию в качестве аргумента
        notify_1 = threading.Thread(target=notif_1, args=(message,))
        notify_2 = threading.Thread(target=notif_2, args=(message,))
        notify_3 = threading.Thread(target=notif_3, args=(message,))

        notify_1.start()
        notify_2.start()
        notify_3.start()

    # else: ...

    # Проверка на подписку, а полсе запись в базу если она ещё не существует.
    # if restart == False:
    #     start_param = message.text.split('/start ')[1] if len(message.text.split('/start ')) > 1 else None
        
    # if get_url_sub(start_param) == None:
    #     return
    # url = get_url_sub(start_param)
    
    # try:
    #     user = bot.get_chat_member(group_id, message.from_user.id)  # Получение статуса пользователя
    #     if user.status == 'left':
    #         with open('content/video/sub.mp4', 'rb') as videonote:
    #             bot.send_video_note(message.chat.id, videonote, reply_markup=keyboard_subscribe(url), timeout = 60)
    #         return
    #     elif user.status == 'member':
    #         ...
    # except:
    #     with open('content/video/sub.mp4', 'rb') as videonote:
    #         bot.send_video_note(message.chat.id, videonote, reply_markup=keyboard_subscribe(url), timeout = 60)
    #     return

    url = get_url_sub(start_param)
    
    #send_photo(call.message, f'{db_select_message(call.from_user.id, 1)}', '#1', keyboard_start())
    with open('content/video/sub.mp4', 'rb') as videonote:
        bot.send_video_note(message.chat.id, videonote, reply_markup=keyboard_subscribe(url), timeout = 60)
        
def handle_command_send(message: telebot.types.Message): # команда -> [/send] 
    if message.from_user.id in ADMINS:
        get_text(message)

def handle_command_back_send(message: telebot.types.Message): # команда -> [/back_send] 
    if message.from_user.id in ADMINS:
        bot.send_message(message.chat.id, 'Введите текст для конца')
        bot.register_next_step_handler(message, get_text_end)

def handle_command_change(message: telebot.types.Message): # команда -> [/change] 
    if message.from_user.id in ADMINS:
        bot.send_message(message.chat.id, 'Введите id сообщения')
        bot.register_next_step_handler(message, get_text_id)

def handle_command_sub_info(message: telebot.types.Message): # команда -> [/sub_info]
    if message.from_user.id in ADMINS:
        bot.send_message(message.chat.id, 'Введите url подписки')
        bot.register_next_step_handler(message, get_url)

def handle_command_lendings_info(message: telebot.types.Message): # команда -> [/lendings_info]
    if message.from_user.id in ADMINS:
        bot.send_message(message.chat.id, 'Введите номер аудитории')
        bot.register_next_step_handler(message, get_number_auditoria)


def handle_command_info(message: telebot.types.Message): # команда -> [/info]
    if message.from_user.id in ADMINS:
        message_counts = db_select_message_ids()
        bot.send_message(message.chat.id, f'{message_counts}')

def handle_command_get_user(message: telebot.types.Message): # команда -> [/get_user]
    if message.from_user.id in ADMINS:
        bot.send_message(message.chat.id, 'Введите id пользователя')
        bot.register_next_step_handler(message, get_id)
