from config import *
from keyboards.inline import *
from steps.get_id import *
from send_photo import *

def handle_callback_query(call: telebot.types.CallbackQuery):
    if call.data == 'start':
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 2)}', reply_markup=keyboard_yn_1())
        
    if call.data == 'chek':
        url = db_select_link_referal(call.from_user.id)
        bot.send_message(call.message.chat.id, f'''بعد تسجيل الدخول إلى حساب Quotex الخاص بك، انتقل إلى قسم "الحساب". يمكنك العثور عليه على الجانب الأيسر من لوحة التحكم أو ببساطة استخدم هذا الرابط: 

<a href="{url}">إعدادات الحساب.</a>

على الجانب الأيسر من الشاشة، ستجد معلومات ملفك الشخصي، بما في ذلك رقم التعريف الخاص بك.


أدخل معرفك بعد النقر على الزر أدناه''', parse_mode='html', reply_markup=keyboard_send())
        db_select_message(call.from_user.id, 10)

    if call.data == 'chek_id':  # Первичный запрос в логике бота на првоерку регистрации (Ручной ввод id)

        if db_select_user_activity(call.message.chat.id) == 0:
            bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 14)}')
            bot.register_next_step_handler(call.message, get_id, 'register')

    if call.data == 'yes_1': # Первичный запрос в логике бота на првоерку регистрации (Ручной ввод id)
        send_photo(call.message, f'{db_select_message(call.from_user.id, 3)}', '#3')
        bot.register_next_step_handler(call.message, get_id, 'proverka_id')

    if call.data == 'chek_id_deposit':  # Проверка депозита
        if db_select_user_activity(call.message.chat.id) == 0:
            value = db_select_user_id_q(call.from_user.id)
            db_add_request_k(call.from_user.id, value)
            bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 26)}')
            print(f'ID пользователя: {call.from_user.id}\nID квотекст: {value}')
            # Создаём поток на ожидание ответа от user бота и когда увидим в отправленном от user агента сообщение в бд с нашим id отправялем value
            cheked_answers = threading.Thread(target=cheked_answer, args=(call.message, 'deposit', True))
            cheked_answers.start()
            cheked_answers.join()

    if call.data == 'register_or_deposit': # Проверка на уведомление
            if db_select_user_id_q(call.from_user.id) != None:
                value = db_select_user_id_q(call.from_user.id)
                db_add_request_k(call.from_user.id, value)
                print(f'ID пользователя: {call.from_user.id}\nID квотекст: {value}')
                # Создаём поток на ожидание ответа от user бота и когда увидим в отправленном от user агента сообщение в бд с нашим id отправялем value
                cheked_answers = threading.Thread(target=cheked_answer, args=(call.message, 'register_or_deposit', True))
                cheked_answers.start()
                cheked_answers.join()
            else:
                bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 14)}')
                bot.register_next_step_handler(call.message, get_id, 'register_or_deposit')

    if call.data == 'yes_2':
        url = db_select_link_referal(call.from_user.id)
        #bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 9)}', reply_markup=keyboard_give(url))
        send_photo(call.message, f'{db_select_message(call.from_user.id, 9)}', '#9', keyboard_give(url))

    if call.data == 'no_1':
        url = db_select_link_referal(call.from_user.id)
        #bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 9)}', reply_markup=keyboard_give(url))
        send_photo(call.message, f'{db_select_message(call.from_user.id, 9)}', '#9', keyboard_give(url))

    if call.data == 'no_2':
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 7)}')
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 25)}', parse_mode='html')
        send_photo(call.message, f'{db_select_message(call.from_user.id, 8)}', '#8', keyboard_yn_2())


    if call.data == 'yes_3':
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 5)}', reply_markup=keyboard_localink())

    if call.data == 'no_3':
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 6)}', reply_markup=keyboard_localink())


    if call.data == 'deposit_2':
        value = db_select_user_id_q(call.from_user.id)
        db_add_request_k(call.from_user.id, value)
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 26)}')
        print(f'ID пользователя: {call.from_user.id}\nID квотекст: {value}')

        # Создаём поток на ожидание ответа от user бота и когда увидим в отправленном от user агента сообщение в бд с нашим id отправялем value
        cheked_answers = threading.Thread(target=cheked_answer, args=(call.message, 'deposit_2', True))
        cheked_answers.start()
        cheked_answers.join()

    if call.data == 'fake_deposite':
        bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 19)}', reply_markup=keyboard_localink())

    #if call.data == 'skip':
    #    send_photo(call.message, f'{db_select_message(call.from_user.id, 1)}', '#1', keyboard_start())
        
    # if call.data == 'check_sub':
    #     url = db_select_link_sub(call.from_user.id)
    #     try:
    #         user = bot.get_chat_member(group_id, call.from_user.id)
    #         if user.status == 'left':
    #             with open('content/video/sub.mp4', 'rb') as videonote:
    #                 bot.send_video_note(call.message.chat.id, videonote, reply_markup=keyboard_subscribe(url), timeout = 60)
    #             return
    #         if user.status == 'member':
    #             send_photo(call.message, f'{db_select_message(call.from_user.id, 1)}', '#1', keyboard_start())
    #     except:
    #         with open('content/video/sub.mp4', 'rb') as videonote:
    #             bot.send_video_note(call.message.chat.id, videonote, reply_markup=keyboard_subscribe(url), timeout = 60)
    #         return
        
    # if call.data == 'open9':
    #     url = db_select_link_referal(call.from_user.id)
    #     bot.send_message(call.message.chat.id, f'{db_select_message(call.from_user.id, 9)}', reply_markup=keyboard_give(url))
