from config import *
from handlers.callback import *
from handlers.commands import *
from timers import *

bot.register_message_handler(handle_command_start, commands=['start'])
bot.register_message_handler(handle_command_send, commands=['send'])
bot.register_message_handler(handle_command_back_send, commands=['back_send'])
bot.register_message_handler(handle_command_change, commands=['change'])
bot.register_message_handler(handle_command_sub_info, commands=['sub_info'])
bot.register_message_handler(handle_command_lendings_info, commands=['lendings_info'])
bot.register_message_handler(handle_command_get_user, commands=['get_user'])
bot.register_message_handler(handle_command_info, commands=['info'])

bot.register_callback_query_handler(handle_callback_query, func=lambda call: True)

bot.infinity_polling()

# -1001986773753