from config import *

conn = sqlite3.connect('../database.db')
cursor = conn.cursor()

# cursor.execute('''
# CREATE TABLE k_bot (
#     user TEXT,
#     id INTEGER
# )
# ''')

# cursor.execute('''
# CREATE TABLE user (
#     user_id TEXT,
#     active INTEGER,
#     reg INTEGER,
#     sub INTEGER,
#     depos INTEGER,
#     date TEXT, 
#     auditoria INTEGER,
#     link_sub TEXT,
#     link_referal TEXT,
#     message_id INTEGER
# )
# ''')

# cursor.execute('''
# CREATE TABLE ot_bot (
#     user TEXT,
#     value INTEGER,
# )
# ''')

# cursor.execute('''
# CREATE TABLE texts (
#      back_text TEXT
# )
# ''')

# cursor.execute('''
#     CREATE TABLE IF NOT EXISTS messages (
#         id INTEGER PRIMARY KEY,
#         message TEXT,
#         count INTEGER
#     )
# ''')

# cursor.execute('''
# CREATE TABLE qwotex_users (
#      user_id_q INTEGER,
#      user_id_t INTEGER         
# )
# ''')

def db_select_record(user):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на поиск записи по user и value
    select_query = 'SELECT * FROM ot_bot WHERE user = ?'
    cursor.execute(select_query, (user,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Возвращаем True, если запись найдена, и False в противном случае
    return True if result else False

def db_delete_user_by_user_id(user_id: str):
    '''Функция для удаления записи по user_id.'''
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('DELETE FROM user WHERE user_id = ?', (user_id,))
    conn.commit()


def db_select_value_by_user(user):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на получение значения по имени пользователя
    select_query = 'SELECT value FROM ot_bot WHERE user = ?'
    cursor.execute(select_query, (user,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Возвращаем значение (или None, если запись не найдена)
    return result[0] if result else None



def db_add_request_k(user, user_id):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на вставку данных
    insert_query = 'INSERT INTO k_bot (user, id) VALUES (?, ?)'
    cursor.execute(insert_query, (user, user_id))

    # Коммитим изменения и закрываем соединение
    conn.commit()
    conn.close()


def db_select_and_get_user_id(value):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на поиск значения в таблице
    select_query = 'SELECT user, id FROM k_bot WHERE value = ?'
    cursor.execute(select_query, (value,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Возвращаем результат (или None, если запись не найдена)
    return result

def db_delete_record_by_user_ot(user):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на удаление записи по user
    delete_query = 'DELETE FROM ot_bot WHERE user = ?'
    cursor.execute(delete_query, (user,))
    
    # Применяем изменения и закрываем соединение
    conn.commit()
    conn.close()


def db_update_activity(user_id, active):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на обновление значения activity по user_id
    update_query = 'UPDATE user SET active = ? WHERE user_id = ?'
    cursor.execute(update_query, (active, user_id))
    
    # Применяем изменения
    conn.commit()

    # Закрываем соединение
    conn.close()

# =========================================================================================================================================================================

def db_add_user_start(user_id, date, auditoria, link_sub, link_referal, sub=1, active=0, reg=0, depos=0, message_id=0):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на добавление записи о пользователе
    insert_query = 'INSERT INTO user (user_id, active, reg, sub, depos, date, auditoria, link_sub, link_referal, message_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    cursor.execute(insert_query, (user_id, active, reg, sub, depos, date, auditoria, link_sub, link_referal, message_id))
    
    # Сохраняем изменения и закрываем соединение
    conn.commit()
    conn.close()

def db_delete_qwotex_user(user_id_t: int):
    '''Функция для удаления записи по user_id_t из таблицы qwotex_users.'''
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('DELETE FROM qwotex_users WHERE user_id_t = ?', (user_id_t,))
    conn.commit()

def db_select_auditoria(user_id):
    # Устанавливаем соединение с базой данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Запрос SQL для получения auditoria по user_id
    query = '''SELECT auditoria FROM user WHERE user_id = ?'''

    # Выполняем запрос с переданным user_id
    cursor.execute(query, (user_id,))
    
    # Извлекаем результат
    result = cursor.fetchone()

    # Закрываем соединение с базой данных
    conn.close()

    # Возвращаем значение auditoria или None, если запись не найдена
    if result:
        return result[0]
    else:
        return None


def db_select_sub(user_id: int):
    '''Функция для получения значения sub по user_id'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT sub FROM user WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        return None
    
def db_update_sub(user_id: int, value: int):
    '''Обнолвение sub конкретного user_id'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('UPDATE user SET sub = ? WHERE user_id = ?', (value, user_id))
    conn.commit()

def db_select_link_sub(user_id: int):
    '''Получение значения link_sub по user_id'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT link_sub FROM user WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        return None
    
def db_select_all_sub_po_url(url: str) -> list: 
    '''Функция для получения количества подписчиков по конкретной url_sub'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM user WHERE link_sub = ? AND sub = 1', (url,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        return 0
    
def db_select_link_referal(user_id: int) -> Optional[int]:
    '''Функция для получения значения link_referal по user_id.
    
    Args:
        user_id (str): Идентификатор пользователя.
        
    Returns:
        Optional[str]: Значение link_referal или None, если пользователь не найден.
    '''
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT link_referal FROM user WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    
    if result:
        return result[0]
    else:
        return None

def db_select_all_auditoria(auditoria_number: int):
    '''Функция для получения количества пользователей с определённой лендинга'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM user WHERE auditoria = ?', (auditoria_number,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        return 0    

# =========================================================================================================================================================================

def db_select_user_exists(user_id):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на поиск записи по user_id
    select_query = 'SELECT * FROM user WHERE user_id = ?'
    cursor.execute(select_query, (user_id,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Если запись найдена, вернуть True, иначе False
    return True if result else False

def db_select_user_activity(user_id):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на поиск записи по user_id
    select_query = 'SELECT active FROM user WHERE user_id = ?'
    cursor.execute(select_query, (user_id,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Если запись найдена, вернуть значение activity, иначе None
    return result[0] if result else None


def db_update_user_reg(user_id, reg):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на обновление значения reg
    update_query = 'UPDATE user SET reg = ? WHERE user_id = ?'
    cursor.execute(update_query, (reg, user_id))
    
    # Сохраняем изменения и закрываем соединение
    conn.commit()
    conn.close()


def db_update_user_depos(user_id, depos):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на обновление значения depos
    update_query = 'UPDATE user SET depos = ? WHERE user_id = ?'
    cursor.execute(update_query, (depos, user_id))
    
    # Сохраняем изменения и закрываем соединение
    conn.commit()
    conn.close()



def db_get_reg_by_user_id(user_id):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    select_query = 'SELECT reg FROM user WHERE user_id = ?'
    cursor.execute(select_query, (user_id,))
    result = cursor.fetchone()

    conn.close()

    return result[0] if result else None

def db_get_depos_by_user_id(user_id):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    select_query = 'SELECT depos FROM user WHERE user_id = ?'
    cursor.execute(select_query, (user_id,))
    result = cursor.fetchone()

    conn.close()

    return result[0] if result else None

def db_get_date_by_user_id(user_id):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    select_query = 'SELECT date FROM user WHERE user_id = ?'
    cursor.execute(select_query, (user_id,))
    result = cursor.fetchone()

    conn.close()

    return result[0] if result else None

def db_select_message_ids():
    '''Функция для подсчета количества каждого message_id в таблице messages, сгруппированных по auditoria.'''
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # SQL-запрос для подсчета количества каждого message_id, сгруппированных по auditoria
    cursor.execute('SELECT auditoria, message_id, COUNT(*) FROM user GROUP BY auditoria, message_id')
    results = cursor.fetchall()

    if results:
        message = ""
        current_auditoria = None  # Для отслеживания текущей auditoria
        for result in results:
            auditoria, message_id, count = result
            if auditoria != current_auditoria:
                if current_auditoria is not None:
                    message += "\n"  # Добавляем пустую строку между разными auditoria
                message += f"Аудитория {auditoria}:\n"
                current_auditoria = auditoria
            message += f"Сообщение #{message_id} - {count}\n"
        
        return message
    else:
        return "Нет данных о сообщениях"

def db_get_all_user_ids():
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на выборку всех user_id
    select_query = 'SELECT user_id FROM user'
    cursor.execute(select_query)
    
    # Получаем результат запроса
    result = cursor.fetchall()

    # Закрываем соединение
    conn.close()

    # Преобразуем результат в список и возвращаем его
    return [row[0] for row in result]


def get_user_ids_with_reg_0():
    # Подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполнение SQL-запроса для получения user_id у которых reg = 0
    cursor.execute("SELECT user_id FROM user WHERE reg=0")
    user_ids_with_reg_0 = cursor.fetchall()

    # Закрытие соединения с базой данных
    conn.close()

    return [user_id[0] for user_id in user_ids_with_reg_0]

def add_value_to_table(value):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()
    
    try:
        cursor.execute("INSERT INTO texts (back_text) VALUES (?)", (value,))
        conn.commit()
        print("Значение успешно добавлено в таблицу.")
    except sqlite3.Error as e:
        print("Ошибка при добавлении значения:", e)
    finally:
        conn.close()

def fetch_values_from_table():
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT back_text FROM texts")
        values = cursor.fetchall()
        return values
    except sqlite3.Error as e:
        print("Ошибка при извлечении значений:", e)
    finally:
        conn.close()


def db_check_back_text_exists():
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT back_text FROM texts LIMIT 1')
    first_row = cursor.fetchone()

    conn.close()

    return first_row is not None


def db_update_first_back_text(new_text):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('UPDATE texts SET back_text = ? WHERE rowid = 1', (new_text,))
    conn.commit()

    conn.close()

# Функция для добавления сообщения в таблицу
def db_add_message(message):

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('INSERT INTO messages (message) VALUES (?)', (message,))
    conn.commit()


def db_select_message(user_id, message_id):
    '''Добавление и получение информации по сообщению.'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    if message_id == 21 or message_id == 22 or message_id == 23:
        # Выбираем сообщение с обновленным значением count
        cursor.execute('SELECT message FROM messages WHERE id = ?', (message_id,))
        result = cursor.fetchone()
        return result[0]

    # Обновляем значение count для указанного message_id
    cursor.execute('UPDATE messages SET count = count + 1 WHERE id = ?', (message_id,))
    conn.commit()

    # Выбираем сообщение с обновленным значением count
    cursor.execute('SELECT message FROM messages WHERE id = ?', (message_id,))
    result = cursor.fetchone()
    if result:
        message = result[0]

        # Добавляем message_id в таблицу user
        cursor.execute('UPDATE user SET message_id = ? WHERE user_id = ?', (message_id, user_id))
        conn.commit()

        return message
    else:
        return None
    
def db_message_exists_by_id(message_id):
    '''Функция для проверки существования сообщения по message_id.'''
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем SQL-запрос для проверки существования сообщения с заданным message_id
    cursor.execute('SELECT EXISTS (SELECT 1 FROM messages WHERE id = ? LIMIT 1)', (message_id,))
    result = cursor.fetchone()

    if result and result[0] == 1:
        return True
    else:
        return False
    

def db_update_message(id, new_message):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()
    
    cursor.execute('UPDATE messages SET message = ? WHERE id = ?', (new_message, id))
    conn.commit()

def db_get_all_message_counts():
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT id, count FROM messages')
    results = cursor.fetchall()

    message_counts = {}
    for id, count in results:
        message_counts[id] = count

    return message_counts

# ============================================ РАБОТА С ЛЕНДИНГОМ И СТАРТОВЫМ ЗАХОДОМ ПОЛЬЗОВАТЕЛЯ =================================#

def db_select_auditoria(user_id):
    # Подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполнение запроса к таблице user
    query = f"SELECT auditoria FROM user WHERE user_id = ?"
    cursor.execute(query, (user_id,))
    result = cursor.fetchone()

    # Закрытие соединения с базой данных
    cursor.close()
    conn.close()

    if result:
        return result[0]  # Возвращаем значение auditoria
    else:
        return None  # Если пользователя с таким user_id не найдено

# ============================================ Сохранение qwotex id =================================================================#


def db_add_qt(user_id_q, user_id_t):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Проверяем, есть ли уже такой user_id_t в таблице
    cursor.execute('SELECT user_id_t FROM qwotex_users WHERE user_id_t = ?', (user_id_t,))
    existing_user = cursor.fetchone()

    if existing_user:   
        ...
    else:
        cursor.execute('INSERT INTO qwotex_users (user_id_q, user_id_t) VALUES (?, ?)', (user_id_q, user_id_t))
        conn.commit()


def db_select_user_id_q(user_id_t):
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    cursor.execute('SELECT user_id_q FROM qwotex_users WHERE user_id_t = ?', (user_id_t,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        return None
    

#  ======================================= Допы

def db_select_all_table_user():
    '''Получение id всех юзеров из user'''

    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()
    
    # Выполняем SQL-запрос для выбора всех user_id из таблицы user
    cursor.execute('SELECT user_id FROM user')
    
    # Извлекаем все строки результата
    rows = cursor.fetchall()
    
    # Закрываем соединение с базой данных
    conn.close()
    
    # Преобразуем результаты в список user_id
    user_ids = [row[0] for row in rows]
    
    return user_ids