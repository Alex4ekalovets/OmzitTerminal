import telebot
import requests
from bs4 import BeautifulSoup
import re
import threading
import asyncio
import sqlite3
import datetime
import time
import logging
from typing import Optional

# Telegram bot
bot = telebot.TeleBot('6408423393:AAHb-UewAhHmst6QsFafvpOlYzfPjQMCzg4') #6408423393:AAHb-UewAhHmst6QsFafvpOlYzfPjQMCzg4 
group_id = -1001986773753
ADMINS = [5116330135, 5040074530, 5926352552, 6552285312]


# logger = telebot.logger
# telebot.logger.setLevel(logging.DEBUG)
