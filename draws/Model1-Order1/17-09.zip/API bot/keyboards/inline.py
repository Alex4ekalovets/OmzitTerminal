from config import *
from db import *


def keyboard_start() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_give_bot = telebot.types.InlineKeyboardButton('➡️ اذهب للتسجيل 🔥', callback_data='start')
    keyboard.add(btn_give_bot)

    return keyboard

def keyboard_give(url) -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup(row_width=1)
    btn_url_register = telebot.types.InlineKeyboardButton(' ➡️ تسجيل 💸', url=url)
    btn_check_id = telebot.types.InlineKeyboardButton(' ➡️ أدخل معرف Quotex الخاص بك 💸', callback_data='chek')
    keyboard.add(btn_url_register, btn_check_id)

    return keyboard

def keyboard_send() -> telebot.types.InlineKeyboardMarkup:
    keyboard = telebot.types.InlineKeyboardMarkup(row_width=1)
    btn_check_id = telebot.types.InlineKeyboardButton(' ➡️ ارسل رقم التعريف الخاص بك على Quotex 💸', callback_data='chek_id')
    keyboard.add(btn_check_id)

    return keyboard

def keyboard_solo_check() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_check_id = telebot.types.InlineKeyboardButton(' ➡️ مسجَل بالفعل؟ قم بتأكيد رقم التعريف الخاص بك 💸', callback_data='chek')
    keyboard.add(btn_check_id)

    return keyboard


def keyboard_check_deposit() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_check_id = telebot.types.InlineKeyboardButton("➡️ !لقد قمت بالإيداع، يرجى التحقق 💸", callback_data='chek_id_deposit')
    keyboard.add(btn_check_id)

    return keyboard

def keyboard_go() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_check_id = telebot.types.InlineKeyboardButton(" ➡️  انطلق 💸", url='https://t.me/+HmmNviKBg68wM2Nh')
    keyboard.add(btn_check_id)

    return keyboard

def keyboard_register(url: str) -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_give_bot = telebot.types.InlineKeyboardButton(' ➡️تسجيل  💸', url=url)
    keyboard.add(btn_give_bot)

    return keyboard

def keyboard_yn_1() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_yes = telebot.types.InlineKeyboardButton(' ➡️ نعم', callback_data='yes_1')
    btn_no = telebot.types.InlineKeyboardButton(' ➡️ لا', callback_data='no_1')
    keyboard.add(btn_yes, btn_no)

    return keyboard

def keyboard_yn_2() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_yes = telebot.types.InlineKeyboardButton(' ➡️ نعم', callback_data='yes_2')
    btn_no = telebot.types.InlineKeyboardButton(' ➡️ ل', callback_data='no_2')
    keyboard.add(btn_yes, btn_no)

    return keyboard

def keyboard_yn_3() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_yes = telebot.types.InlineKeyboardButton('نعم', callback_data='yes_3')
    btn_no = telebot.types.InlineKeyboardButton('لا', callback_data='no_3')
    keyboard.add(btn_yes, btn_no)

    return keyboard

def keyboard_localink() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()
    btn_link = telebot.types.InlineKeyboardButton('اكتب', url='https://t.me/Ali_Trade_Official')
    keyboard.add(btn_link)

    return keyboard

def keyboard_check_deposite_2() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup()    
    btn_check_deposit = telebot.types.InlineKeyboardButton("➡️ لقد قمت بالإيداع، يرجى التحقق!💸", callback_data='deposit_2')
    keyboard.add(btn_check_deposit)

    return keyboard

def keyboard_locals() -> telebot.types.InlineKeyboardMarkup:


    keyboard = telebot.types.InlineKeyboardMarkup()    
    btn_check_deposit = telebot.types.InlineKeyboardButton("➡️ I've made a deposit, please check!💸", callback_data='chek_id_deposit_2')
    keyboard.add(btn_check_deposit)

    return keyboard

def keyboard_fake_deposite() -> telebot.types.InlineKeyboardMarkup:


    keyboard = telebot.types.InlineKeyboardMarkup()    
    btn_check_deposit = telebot.types.InlineKeyboardButton("لقد قمت بإجراء أول إيداع لي", callback_data='fake_deposite')
    keyboard.add(btn_check_deposit)

    return keyboard


def keyboard_subscribe(url: str) -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup(row_width=1)
    btn_sub_link = telebot.types.InlineKeyboardButton(" ➡️ يشترك", url=url)
    btn_sub = telebot.types.InlineKeyboardButton(" ➡️ يتخطى", callback_data='skip')
    keyboard.add(btn_sub_link, btn_sub)

    return keyboard


def keyboard_notify() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup(row_width=1)
    btn_register_or_deposit = telebot.types.InlineKeyboardButton("لقد سجلت وأودعت الإيداع", callback_data='chek')
    keyboard.add(btn_register_or_deposit)

    return keyboard

def keyboard_open_num9() -> telebot.types.InlineKeyboardMarkup:

    keyboard = telebot.types.InlineKeyboardMarkup(row_width=1)
    btn_register_or_deposit = telebot.types.InlineKeyboardButton("🚀تسجيل", callback_data='open9')
    keyboard.add(btn_register_or_deposit)

    return keyboard