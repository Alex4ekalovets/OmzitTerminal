from config import *
from db import *


def get_number_auditoria(message: telebot.types.Message):
    '''Получение количества аудитории пришедших с определённого лендинга'''

    auditoria_count = db_select_all_auditoria(message.text)
    bot.send_message(message.chat.id, f'Количество пользователей аудитории #{message.text}: {auditoria_count}')