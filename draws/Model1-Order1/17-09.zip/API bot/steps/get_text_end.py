from config import *
from db import *


def get_text_end(message: telebot.types.Message):
    print(1)
    if db_check_back_text_exists():
        print(2)
        db_update_first_back_text(message.text)
        bot.send_message(message.chat.id, 'Текст обновлён')
    else:
        print(3)
        add_value_to_table(message.text)
        bot.send_message(message.chat.id, 'Добавлен текст в конец')
