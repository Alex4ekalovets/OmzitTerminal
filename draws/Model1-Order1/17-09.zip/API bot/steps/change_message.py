from config import *
from db import *


def get_text_id(message: telebot.types.Message):
    message_id = message.text
    if db_message_exists_by_id(message_id) == True: 
        bot.send_message(message.chat.id, 'Введите новый текст')
        bot.register_next_step_handler(message, get_new_text, message_id)
    else:
        bot.send_message(message.chat.id, 'Данное сообщение не найдено')
        bot.register_next_step_handler(message, get_text_id)
    


def get_new_text(message: telebot.types.Message, message_id):
    # try:
    db_update_message(message_id, message.text)
    bot.send_message(message.chat.id, f'Сообщение <b>#{message_id}</b> изменено.', parse_mode='html')
    # except:
    #     bot.send_message(message.chat.id, 'Сообщение не смогло быть заменено, так как произошла ошибка.')