from config import *
from db import *
from keyboards.inline import *
from send_photo import *

def get_id(message: telebot.types.Message, info: str):
    value = message.text
    if validate_text(value):
        if info == 'register':  # Пользователь на 10 сообщении нажал кнопку
            bot.send_message(message.chat.id, f'{db_select_message(message.from_user.id, 11)}')
            db_add_request_k(message.from_user.id, value)
            db_add_qt(message.text, message.from_user.id)
        elif info == 'proverka_id':
            bot.send_message(message.chat.id, f'{db_select_message(message.from_user.id, 15)}')
            db_add_request_k(message.from_user.id, value)
            db_add_qt(message.text, message.from_user.id)
        elif info == 'register_or_deposit':
            bot.send_message(message.chat.id, f'{db_select_message(message.from_user.id, 11)}')
            db_add_request_k(message.from_user.id, value)

        # Создаём поток на ожидание ответа от user бота и когда увидим в отправленном от user агента сообщение в бд с нашим id отправялем value
        cheked_answers = threading.Thread(target=cheked_answer, args=(message, info, False, value))
        cheked_answers.start()
        cheked_answers.join()

    else:
        bot.send_message(message.chat.id, f'{db_select_message(message.from_user.id, 24)}', parse_mode='Markdown')
        bot.register_next_step_handler(message, get_id)

def cheked_answer(message: telebot.types.Message, info: str, only_ckick, value=0):
    while True:
        if db_select_record(message.chat.id) == False:
            ... # Постоянное состояние
        elif db_select_record(message.chat.id):
            if value == 0 and only_ckick == False:
                db_update_activity(message.from_user.id, 0)                 # Обновление активности, пользователь может нажимать
                db_delete_record_by_user_ot(message.chat.id)                # Удаление из базы данных запроса
                break

            balance = db_select_value_by_user(message.chat.id)          # Получение значения счёта
            db_update_activity(message.from_user.id, 0)                 # Обновление активности, пользователь может нажимать
            db_delete_record_by_user_ot(message.chat.id)                # Удаление из базы данных запроса

            if balance == 'None': balance = None  # Переводим из строкового значения в NoneType
            print(f'''Запрос: {info}\nБаланс: {balance}''')

            if only_ckick == False:
                if info == 'register_or_deposit':
                    print(db_select_user_id_q(message.from_user.id))
                    if db_select_user_id_q(message.from_user.id) == None:
                        info = 'register'
                        if only_ckick == False and value != 0:
                            db_add_qt(value, message.from_user.id)
            else:
                info = 'deposit'

            if info == 'register':      # Проверка при регистрации

                if balance == None: # Если такого аккаунта с таким id нету.
                    send_photo(message, f'{db_select_message(message.from_user.id, 12)}', '#12', keyboard_solo_check())
                    

                elif balance != None:   # Аккаунт по нашей рефералке существует.
                    url = db_select_link_referal(message.from_user.id)
                    send_photo(message, f'''أخبار مثيرة!
الآن، حسابك موجود في قاعدة بياناتنا، وأنت على بعد خطوة واحدة فقط من فتح باب النجاح في التداول.

لا تنتظر أكثر - اتخذ الخطوة الأخيرة الآن وأودع مبلغًا لا يقل عن 30 دولار أمريكي.
(نحن نوصي بمبلغ 98 دولار أمريكي، حيث وجد فريقنا ثغرة في خوارزميات التداول)
وكهدية ستحصل على وصول إلى قناتنا الخاصة VIP مجانًا تمامًا.

رحلتك المالية على وشك البدء - استغل هذه الفرصة!

<a href='{url}'>اقوم بعمل الإيداع الآن</a>''', '#13', keyboard_check_deposit())
                    db_select_message(message.from_user.id, 13)
                    db_update_user_reg(message.from_user.id, 1)

            elif info == 'deposit':     # Проверка на внесение депозита

                if balance != None: # Обновляем статус регистрации
                    db_update_user_reg(message.from_user.id, 1)

                if balance < 30:    # Если баланс меньше 30 $ пишем что не найден аккаунт в базе.
                    url = db_select_link_referal(message.from_user.id)
                    send_photo(message, f'''لم نتمكن من العثور على إيداعك في قاعدة البيانات الخاصة بنا. يرجى التأكد من إتمام عملية الإيداع وتوفير رقم الهوية 
الصحيح."

<a href='{url}'>اقوم بعمل إيداع الآن</a>''', '#17', keyboard=keyboard_check_deposite_2())
                    db_select_message(message.from_user.id, 17)

                elif balance >= 30: # Если баланс найден и он с депозитом более 30 $ добавляем в аккаунт
                    with open('content/video/16.mp4', 'rb') as videonote:
                        bot.send_video_note(message.chat.id, videonote, reply_markup=keyboard_go(), timeout = 60)
                    db_update_user_depos(message.from_user.id, 1)

            elif info == 'deposit_2':   # Возможные ошибки проверки с перенаправлением личку, так же и повторная проверка id

                if balance != None: # Обновляем статус регистрации
                    db_update_user_reg(message.from_user.id, 1)

                if balance < 30:    # Если баланс не найден направляем в личку.
                    bot.send_message(message.chat.id, f'{db_select_message(message.from_user.id, 18)}', reply_markup=keyboard_fake_deposite())

                elif balance >= 30: # Если баланс найден и он с депозитом более 30 $ добавляем в аккаунт
                    bot.send_message(message.chat.id, f'{db_select_message(message.from_user.id, 16)}', reply_markup=keyboard_go())
                    db_update_user_depos(message.from_user.id, 1)

            break # Выходим из цикла после проведения действий.


def validate_text(text):
    # Паттерн для поиска строки, содержащей только до 11 цифр
    pattern = r"^\d{1,10}$"
    
    # Проверяем, соответствует ли текст паттерну
    if re.match(pattern, text):
        return True
    else:
        return False