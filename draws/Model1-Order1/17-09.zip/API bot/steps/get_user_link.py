from config import *


def get_id(message: telebot.types.Message):
    try:
        user_id = message.text
        link = bot.get_chat_member(message.chat.id, user_id).user.full_name
        link = f'https://t.me/{link}'
        bot.send_message(message.chat.id, link)
    except:
        bot.send_message(message.chat.id, 'Пользователь не найден или заблокировал бота. Для получения ссылки требутеся что бы пользователь был в активном диалоге и не блокировал бота.')