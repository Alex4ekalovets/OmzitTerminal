from config import *
from db import *


def get_url(message: telebot.types.Message):
    '''Получение ссылки url для подписки на канал и вывода статистики подписок по ней'''

    link = message.text 
    count_subscribe = db_select_all_sub_po_url(link)
    
    bot.send_message(message.chat.id, f'Подписок по ссылке {link}: {count_subscribe}')