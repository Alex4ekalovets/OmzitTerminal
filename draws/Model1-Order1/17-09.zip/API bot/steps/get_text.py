from db import *
from keyboards.inline import *

def get_text(message: telebot.types.Message):
    users = db_select_all_table_user()
    print(users)
    for user_id in users:
        try:
            url = db_select_link_referal(message.from_user.id)
            bot.send_message(int(user_id), f'''مرحبًا! 🌟

تفتح أبواب الفرصة أمامك الآن! من خلال الانضمام إلى منصة Quotex وإيداع مبلغ 50 دولارًا عبر رابط الإحالة الخاص بي، ستكون على وشك دخول عالم التداول المتقدم والحصول على فرصة حقيقية لتحقيق أهدافك المالية.

عندما تقوم بالإيداع، سأقدم لك الوصول الفوري إلى قناة VIP الخاصة بي حيث أقدم إشارات حصرية وتوجيهات قيمة للتداول. ستتعلم من تجاربي وتجارتي الناجحة وتستفيد منها لتحسين حياتك المالية.

لا تفوت هذه الفرصة الفريدة! ابدأ الآن واجعل مستقبلك مشرقًا وواعدًا. انقر على الرابط وقم بالإيداع:

<a href='{url}'>الإيداع على منصة Quotex</a>

بدأ الرحلة نحو التحقيق في أهدافك المالية وتحقيق حياة أفضل. نحن هنا لمساعدتك في كل خطوة على الطريق. 🚀''', parse_mode='html', reply_markup=keyboard_notify())
        except: 
            print(user_id, 'добавил в блок лист бота')

