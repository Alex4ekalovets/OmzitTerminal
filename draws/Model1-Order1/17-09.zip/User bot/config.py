from pyrogram import Client, filters
from pyrogram.types import Message
import sqlite3
import threading
import re

api_id = 20009557
api_hash = '6af86bd1bace0ba19088aea725b4bb74'
chat_id = '@QuotexPartnerBot'