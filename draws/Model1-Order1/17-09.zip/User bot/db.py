from config import *

conn = sqlite3.connect('../database.db')
cursor = conn.cursor()

# cursor.execute('''
# CREATE TABLE k_bot (
#     user TEXT,
#     id INTEGER
# )
# ''')

# cursor.execute('''
# CREATE TABLE ot_bot (
#     user TEXT,
#     value INTEGER
# )
# ''')


def db_select_user_by_id_k(user_id):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на поиск записи по user_id
    select_query = 'SELECT user FROM k_bot WHERE id = ?'
    cursor.execute(select_query, (user_id,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Возвращаем результат (или None, если запись не найдена)
    return result[0] if result else None

def db_delete_user_by_user_id_k(user_id):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на удаление записи по имени пользователя
    delete_query = 'DELETE FROM k_bot WHERE user = ?'
    cursor.execute(delete_query, (user_id,))
    
    # Коммитим изменения и закрываем соединение
    conn.commit()

def db_add_request_ot(user, value):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на вставку данных
    insert_query = 'INSERT INTO ot_bot (user, value) VALUES (?, ?)'
    cursor.execute(insert_query, (user, value))

    # Коммитим изменения и закрываем соединение
    conn.commit()
    conn.close()

def db_select_and_get_user_id(value):
    # Создаем подключение к базе данных
    conn = sqlite3.connect('../database.db')
    cursor = conn.cursor()

    # Выполняем запрос на поиск значения в таблице
    select_query = 'SELECT user, id FROM k_bot WHERE value = ?'
    cursor.execute(select_query, (value,))
    
    # Получаем результат запроса
    result = cursor.fetchone()

    # Закрываем соединение
    conn.close()

    # Возвращаем результат (или None, если запись не найдена)
    return result

def check_and_get_user_id():
    # Создаем подключение к базе данных
    with sqlite3.connect('../database.db') as conn:
        cursor = conn.cursor()

        # Выполняем запрос на получение записи
        select_query = 'SELECT user, id FROM k_bot'
        cursor.execute(select_query)

        # Получаем результат запроса
        result = cursor.fetchone()

    # Возвращаем результат (или None, если запись не найдена)
    return result