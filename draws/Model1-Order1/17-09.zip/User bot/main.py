import asyncio
from config import *
from db import *
from pyrogram import Client

app = Client("my_account", api_id=api_id, api_hash=api_hash)

# Функция для извлечения цифр из текста
def extract_numbers(text):
    return re.sub(r'\D', '', text)

async def cheked_answer():
    await app.start()
    while True:
        result = check_and_get_user_id()
        if result:
            user, user_id = result
            await app.send_message(chat_id, f"{user_id}")
        else: ...
        await asyncio.sleep(1)  # Добавьте паузу, чтобы не перегружать цикл

@app.on_message()
def handle_message(client, message: Message):
    bot_name = f'@{message.from_user.first_name}'
    if bot_name == chat_id:
        if message.from_user.id == 5926352552:
            return

        message_text = message.text
        message_lines = message_text.split('\n')

        if len(message_lines) >= 8:
            user_id = message_lines[0].split('#')[1].strip()
            balance_line = message_lines[6]
            # Используем регулярное выражение для поиска числа
            match = re.search(r'\d+\.\d+', balance_line)
            balance = int(float(match.group()))
            user = db_select_user_by_id_k(user_id)
            db_delete_user_by_user_id_k(user)
            db_add_request_ot(user, f'{balance}')

        else:
            user_id = extract_numbers(message_text)
            user = db_select_user_by_id_k(user_id)
            db_delete_user_by_user_id_k(user)
            db_add_request_ot(user, 'None')

loop = asyncio.get_event_loop() 
loop.run_until_complete(cheked_answer())